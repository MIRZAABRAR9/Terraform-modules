# Terraform Modules

Reusable OpenTofu/Terraform modules maintained and offered by [xtralinux.com](https://xtralinux.com).

## Modules

| Module | Description |
|---|---|
| `modules/cloudflare/zone` | Cloudflare zones and granular zone settings. |
| `modules/cloudflare/dns-records` | Cloudflare DNS records in a single zone. |
| `modules/cloudflare/worker-domains` | Cloudflare Workers custom domains. |
| `modules/cloudflare/r2_bucket` | Cloudflare R2 buckets with location, jurisdiction, storage class, lifecycle rules, CORS, custom domains, and r2.dev access. |
| `modules/cloudflare/workers_script` | Cloudflare Worker records (observability, subdomain, tags, tail consumers); script content stays with wrangler. |
| `modules/cloudflare/workers_route` | Cloudflare Workers routes attaching URL patterns to Worker scripts. |
| `modules/cloudflare/workers-kv` | Cloudflare Workers KV namespaces (classic and KV Instant); key/value content stays out of scope. |
| `modules/cloudflare/pages` | Cloudflare Pages projects: build config, git source, deployment configs, and custom domains. |
| `modules/cloudflare/tunnel` | Cloudflare Tunnels (cloudflared) with tunnel routes and optional remote ingress config. |
| `modules/cloudflare/load-balancer` | Cloudflare load balancers with health monitors, origin pools, and failover/steering wiring. |
| `modules/cloudflare/ruleset` | Cloudflare zone rulesets: WAF custom rules, rate limiting, transforms, redirects, and origin overrides. |
| `modules/cloudflare/access` | Cloudflare Zero Trust Access: identity providers, reusable policies, and applications. |
| `modules/cloudflare/origin-ca-certificate` | Cloudflare Origin CA certificates issued from a CSR. |
| `modules/ns1/zone` | NS1 zones: primary, linked, secondary with TSIG, DNSSEC. |
| `modules/ns1/record` | NS1 DNS records with filter chains, regions, and answers. |
| `modules/ns1/redirect` | NS1 URL redirects. |
| `modules/github/repository` | GitHub repository settings and branch protection. |
| `modules/github/branch-protection` | GitHub branch protection for existing repositories. |
| `modules/github/team` | GitHub teams with nested membership and parent-team wiring. |
| `modules/github/membership` | GitHub organization membership with member/admin roles. |
| `modules/github/repo-access` | GitHub repository access for teams and users per repository. |
| `modules/github/actions-secrets` | GitHub Actions repository secrets keyed by secret name. |
| `modules/github/actions-variables` | GitHub Actions repository variables keyed by variable name. |
| `modules/github/actions-organization-secrets` | GitHub Actions organization secrets with visibility and per-secret repository allow-lists. |
| `modules/github/actions-organization-variables` | GitHub Actions organization variables with visibility and per-variable repository scoping. |
| `modules/github/issue-labels` | GitHub repository issue labels keyed by display name. |
| `modules/github/repository-environments` | GitHub deployment environments with reviewers, branch policies, and nested secrets/variables. |
| `modules/github/webhook` | GitHub repository and organization webhooks with payload configuration. |
| `modules/github/deploy-key` | GitHub repository deploy keys with read-only flag. |
| `modules/equinix/fabric_cloud_router` | Equinix Fabric Cloud Routers (FCR). |
| `modules/equinix/fabric_connection` | Equinix Fabric connections: port, cloud router, virtual device, service token, and service-provider endpoints. |
| `modules/hetzner/network` | Hetzner Cloud networks with RFC1918 ranges, labels, and vSwitch route exposure. |
| `modules/hetzner/zone` | Hetzner Cloud DNS zones, primary or secondary, with primary nameservers and TSIG. |
| `modules/hetzner/floating_ip` | Hetzner Cloud floating IPs with home location or server assignment. |
| `modules/hetzner/firewall` | Hetzner Cloud firewalls with rules and server/label-selector attachments. |
| `modules/hetzner/placement_group` | Hetzner Cloud placement groups (spread) with labels. |
| `modules/hetzner/server` | Hetzner Cloud servers with images, cloud-init, primary IPs, private networks, firewalls, and placement groups. |
| `modules/hetzner/ssh_key` | Hetzner Cloud SSH keys for server authentication. |
| `modules/hetzner/volume` | Hetzner Cloud volumes with optional server attachment and formatting. |
| `modules/hetzner/load_balancer` | Hetzner Cloud load balancers with services (HTTP/HTTPS/TCP), health checks, sticky sessions, and server/label-selector/IP targets. |
| `modules/hetzner/certificate` | Hetzner Cloud TLS certificates: Hetzner-managed by domain names or uploaded PEM certificates with private keys. |
| `modules/hetzner/primary_ip` | Hetzner Cloud primary IPs, unassigned in a location or assigned to a server. |
| `modules/hetzner/rdns` | Hetzner Cloud reverse DNS entries for servers, primary IPs, floating IPs, and load balancers. |
| `modules/aws/vpc` | AWS VPCs with DNS settings, tenancy, IPAM IPv4 and generated IPv6 CIDRs. |
| `modules/aws/subnet` | AWS VPC subnets with IPv4/IPv6 CIDRs, AZ allocation, and public-IP assignment. |
| `modules/aws/nat` | AWS NAT gateways with optional elastic IPs, public or private connectivity. |
| `modules/aws/vpc-endpoints` | AWS VPC endpoints (gateway and interface) with route-table/subnet wiring, endpoint policies, private DNS options, and S3 multi-VPCE support. |
| `modules/aws/security-group` | AWS security groups with separate ingress and egress rule resources. |
| `modules/aws/iam-role` | AWS IAM roles with trust policies, managed and inline policies, and optional instance profiles. |
| `modules/aws/iam-user` | AWS IAM users with group memberships, managed and inline policies, and optional access keys. |
| `modules/aws/iam-group` | AWS IAM groups with managed and inline policies; membership is managed on the user side. |
| `modules/aws/ec2-instance` | AWS EC2 instances with AMI via SSM lookup, EBS volumes, and instance profile pass-through. |
| `modules/aws/s3-bucket` | AWS S3 buckets with versioning, SSE, public access block, ownership controls, lifecycle, object lock, replication, and notifications. |
| `modules/aws/dynamodb` | AWS DynamoDB tables with capacity modes, secondary indexes, streams, TTL, PITR, SSE, and deletion protection. |
| `modules/aws/sqs` | AWS SQS queues with FIFO support, SSE, dead-letter redrive, and redrive-allow policies. |
| `modules/aws/sns` | AWS SNS topics with FIFO support, topic policies, delivery feedback, and subscriptions with filter policies. |
| `modules/aws/site-to-site-vpn` | AWS Site-to-Site VPN: customer gateways, virtual private gateways, connections with VGW or Transit Gateway attachment, tunnel options, and static routes. |
| `modules/aws/route53-zone` | AWS Route 53 hosted zones: public and private with VPC associations and delegation sets. |
| `modules/aws/route53-records` | AWS Route 53 record sets across hosted zones with standard and alias records. |
| `modules/aws/alb` | AWS load balancers (application, network, gateway) with target groups, attachments, listeners, and listener rules. |
| `modules/aws/rds` | AWS RDS standalone DB instances and Aurora clusters with member instances, storage, backups, and encryption. |
| `modules/aws/ecs-cluster` | AWS ECS clusters with container insights, execute-command configuration, and capacity provider strategies. |
| `modules/aws/ecs-service` | AWS ECS services with task definitions, FARGATE/EC2 launch, networking, load balancer targets, and circuit breakers. |
| `modules/aws/ecr` | AWS ECR private repositories with tag mutability, scan-on-push, KMS/AES256 encryption, lifecycle and repository policies. |
| `modules/aws/ecr-pull-through-cache` | AWS ECR pull-through cache rules for upstream container registries (Docker Hub, ECR, Quay, Kubernetes, GitHub/GitLab/Azure/Chainguard). |
| `modules/aws/kms` | AWS KMS keys with rotation, multi-region, optional policy, and aliases. |
| `modules/aws/lambda` | AWS Lambda functions with S3 packaging, VPC config, layers, event source mappings, and invocation permissions. |
| `modules/aws/secrets-manager` | AWS Secrets Manager secrets with optional values, replica regions, recovery windows, KMS encryption, and rotation schedules. |
| `modules/aws/cloudfront` | AWS CloudFront distributions with origins (custom and S3 via OAC), cache behaviors, WAF, logging, aliases, and geo restrictions. |
| `modules/aws/elasticache` | AWS ElastiCache Redis/Valkey replication groups and memcached clusters with subnet/parameter groups, auth, and snapshots. |
| `modules/aws/cloudwatch` | AWS CloudWatch log groups, metric alarms, and dashboards. |
| `modules/aws/eks` | AWS EKS clusters with managed node groups, addon management, access entries and policy associations, and OIDC providers for IRSA. |
| `modules/aws/acm` | AWS Certificate Manager certificates with DNS/email/Private CA validation and in-module Route 53 validation records. |
| `modules/aws/efs` | AWS EFS file systems with lifecycle policies, throughput/performance modes, encryption, mount targets, and access points. |
| `modules/aws/route53-resolver` | AWS Route 53 Resolver endpoints (inbound, outbound, inbound-delegation), forward/system/recursive rules, and DNSSEC validation configs. |
| `modules/aws/transit-gateway` | AWS Transit Gateway: gateways, route tables, VPC and peering attachments with accepters, and static routes. |
| `modules/aws/eventbridge` | AWS EventBridge event buses with policies, rules and targets, Scheduler schedules with retry/flex-window options, and archives. |
| `modules/aws/step-functions` | AWS Step Functions state machines (Standard and Express) with logging, tracing, encryption and optional version publishing, plus worker activities. |
| `modules/aws/api-gateway` | AWS API Gateway HTTP APIs (v2): routes, integrations, JWT authorizers, stages, and custom domain mappings. |
| `modules/aws/waf` | AWS WAFv2 web ACLs (CLOUDFRONT and REGIONAL scope) with IP sets, rate-based and managed rules, rule groups, and REGIONAL resource associations. |
| `modules/azure/subscription` | Azure subscriptions via the Alias API: new subscriptions under EA/MCA/MPA billing scopes, or adopting existing subscriptions. |
| `modules/azure/subscription-iam` | Azure subscription RBAC role assignments for built-in and custom roles, with ABAC conditions. |
| `modules/azure/resource-group` | Azure resource groups with tags and managed-by metadata, created in the provider's subscription. |
| `modules/azure/virtual-network` | Azure virtual networks with DNS servers, BGP community, flow timeout, and DDoS/encryption options. |
| `modules/azure/subnet` | Azure subnets with address prefixes, delegations, service endpoints, and private-endpoint policies. |
| `modules/azure/network-security-group` | Azure network security groups with security rules as separate rule resources. |
| `modules/azure/public-ip` | Azure public IP addresses with SKU, allocation, DNS labels, zones, and DDoS protection options. |
| `modules/azure/network-interface` | Azure network interfaces with IP configurations, DNS servers, and accelerated networking. |
| `modules/azure/virtual-machine` | Azure virtual machines (Linux and Windows) with OS disks, source images, and SSH/password auth. |
| `modules/azure/managed-identity` | Azure user-assigned managed identities with tags, created in the provider's subscription. |
| `modules/azure/service-bus` | Azure Service Bus namespaces with queues, topics, subscriptions, subscription rules, and per-scope SAS authorization rules. |
| `modules/azure/sql` | Azure SQL Database servers (`azurerm_mssql_*`) with databases, firewall rules, elastic pools, failover groups, Entra admin, and CMK TDE. |
| `modules/azure/event-hubs` | Azure Event Hubs namespaces with event hubs, consumer groups, capture-to-storage, and per-scope SAS authorization rules. |
| `modules/azure/storage-account` | Azure storage accounts with redundancy, TLS/HTTPS policy, network rules, and public access controls. |
| `modules/azure/key-vault` | Azure key vaults with RBAC or legacy access policies, network ACLs, and nested keys, secrets, and certificates. |
| `modules/azure/dns-zone` | Azure DNS zones, public and private, with SOA tuning and private-zone virtual network links. |
| `modules/azure/dns-records` | Azure DNS record sets (A, AAAA, CAA, CNAME, MX, NS, PTR, SRV, TXT) in public or private zones. |
| `modules/azure/aks` | Azure Kubernetes Service clusters with default and additional node pools, Azure CNI/kubenet networking, private clusters, workload identity, and maintenance windows. |
| `modules/azure/nat-gateway` | Azure NAT gateways with public IP and prefix associations. |
| `modules/azure/nat-gateway-association` | Azure subnet-to-NAT gateway associations for outbound SNAT routing. |
| `modules/azure/private-endpoint` | Azure private endpoints with service connections, private DNS zones, and virtual network links. |
| `modules/azure/mysql` | Azure MySQL Flexible Servers with databases, firewall rules, replicas/PITR, HA, and storage tuning. |
| `modules/azure/postgresql` | Azure PostgreSQL Flexible Servers with databases, firewall rules, replicas/PITR/GeoRestore, HA, and storage tuning. |
| `modules/azure/redis` | Azure Cache for Redis with persistence, patch schedules, firewall rules, and geo-replication between same-call caches. |
| `modules/azure/cosmos-db` | Cosmos DB accounts with SQL databases/containers (and Mongo ones) covering consistency, failover regions, backup, and restore. |
| `modules/azure/container-registry` | Azure Container Registries with georeplication, network rules, webhooks, scope maps, and tokens. |
| `modules/azure/application-gateway` | Azure Application Gateways (v2) with autoscale, frontends, Key Vault TLS, listeners, path-based routing, and probes. |
| `modules/azure/load-balancer` | Azure Standard load balancers with frontends (in-module or existing public IPs, or private), backend pools with IP/NIC members, probes, rules, NAT rules, NAT pools, and outbound rules. |
| `modules/azure/log-analytics` | Azure Log Analytics workspaces with linked services and linked storage accounts. |
| `modules/azure/firewall` | Azure Firewalls (VNet and secure-hub) with optional policies, rule collection groups, and in-module public IPs. |
| `modules/azure/app-service` | Azure App Service plans with Linux/Windows web apps, site config, identities, and deployment slots. |
| `modules/azure/functions` | Azure Function Apps (Linux/Windows) with service plans, storage binding, app settings, and returned host keys. |
| `modules/azure/container-app-environment` | Azure Container Apps managed environments with Log Analytics/Azure Monitor logging, workload profiles, VNet injection, and zone redundancy. |
| `modules/azure/container-app` | Azure Container Apps with containers, probes, scale rules, volumes, ingress, secrets, registries, Dapr, and managed identities. |
| `modules/azure/monitor` | Azure Monitor action groups, metric alerts, activity log alerts, scheduled query rules, and diagnostic settings. |
| `modules/azure/web-application-firewall` | Azure Web Application Firewall policies with managed and custom rules, exclusions, and log scrubbing. |
| `modules/gcp/folder` | Google Cloud folders under an organization or parent folder. |
| `modules/gcp/folder-iam` | Google Cloud folder IAM: members, bindings, policy, and audit configs. |
| `modules/gcp/project` | Google Cloud projects. |
| `modules/gcp/project-iam` | Google Cloud project IAM: members, bindings, policy, and audit configs. |
| `modules/gcp/org-policy` | Google Cloud organization policies (org, folder, or project level). |
| `modules/gcp/organization-iam` | Google Cloud organization IAM: members, bindings, policy, and audit configs. |
| `modules/gcp/essential-contacts` | Google Cloud essential contacts at the organization, folder, or project level, with notification-category subscriptions. |
| `modules/gcp/service-account` | Google Cloud service accounts. |
| `modules/gcp/service-account-iam` | Google Cloud service account IAM: members, bindings, and policies. |
| `modules/gcp/bucket` | Google Cloud Storage buckets with optional IAM bindings. |
| `modules/gcp/billing-budget` | Google Cloud billing budgets with threshold and notification rules. |
| `modules/gcp/project-services` | Google Cloud project API (service) enablement. |
| `modules/gcp/compute-instance` | Google Cloud compute instances with optional disks and IAM bindings. |
| `modules/gcp/compute-disk` | Google Cloud persistent disks, snapshots, snapshot schedules, and schedule attachments. |
| `modules/gcp/instance-group-manager` | Google Cloud zonal and regional managed instance groups with optional autoscaling. |
| `modules/gcp/instance-template` | Google Cloud instance templates for managed instance groups. |
| `modules/gcp/firewall` | Google Cloud firewall rules (allow/deny) in a VPC network. |
| `modules/gcp/ha-vpn` | Google Cloud HA VPN: gateways, peer (external) gateways, tunnels, and BGP sessions on Cloud Routers. |
| `modules/gcp/nat` | Google Cloud Router and Cloud NAT gateways. |
| `modules/gcp/static-ip` | Google Cloud regional and global static IP addresses. |
| `modules/gcp/subnet` | Google Cloud subnetworks in a VPC network. |
| `modules/gcp/vpc` | Google Cloud VPC networks. |
| `modules/gcp/vpc-service-controls` | Google VPC Service Controls: access policies, access levels, service perimeters, and perimeter resources. |
| `modules/gcp/vpc-connector` | Google Cloud Serverless VPC Access connectors (dedicated range or shared-VPC subnet). |
| `modules/gcp/gke` | Google Kubernetes Engine clusters with node pools and backup plans. |
| `modules/gcp/load-balancer` | Google Cloud load balancing: health checks, backend services/buckets, URL maps, target proxies, and forwarding rules. |
| `modules/gcp/network-endpoint-group` | Google Cloud network endpoint groups (zonal and regional) with endpoints for GCE VM and hybrid backends. |
| `modules/gcp/target-proxies` | Google Cloud target proxies: TCP (global and regional), SSL, and gRPC for load balancers. |
| `modules/gcp/kms` | Google Cloud KMS key rings, crypto keys, and IAM bindings. |
| `modules/gcp/private-service-connect` | Google Cloud Private Services Access: VPC peering ranges and service networking connections. |
| `modules/gcp/filestore` | Google Cloud Filestore instances with optional backups. |
| `modules/gcp/artifact-registry` | Google Cloud Artifact Registry repositories with optional IAM bindings. |
| `modules/gcp/cloud-armor` | Google Cloud Armor security policies: IP rules, preconfigured WAF rules, rate limiting, redirects, and adaptive protection. |
| `modules/gcp/managed-ssl-certificate` | Google-managed SSL certificates for load balancer target proxies. |
| `modules/gcp/certificate-manager` | Google Certificate Manager certificates, DNS authorizations, and certificate maps with SNI entries. |
| `modules/gcp/ssl-policy` | Google Cloud SSL policies for target HTTPS proxies. |
| `modules/gcp/shared-vpc` | Google Cloud Shared VPC host enablement and service project attachment. |
| `modules/gcp/psc-endpoint` | Google Cloud Private Service Connect consumer endpoints: internal IPs and forwarding rules targeting service attachments. |
| `modules/gcp/logging` | Google Cloud log sinks to Cloud Storage, Pub/Sub, BigQuery, or Cloud Logging with filters and exclusions. |
| `modules/gcp/iam-custom-role` | Google Cloud custom IAM roles at organization or project level. |
| `modules/gcp/cloud-sql` | Google Cloud SQL PostgreSQL/MySQL instances with optional read replicas. |
| `modules/gcp/firestore` | Google Cloud Firestore databases (native, Datastore mode, editions) with CMEK and delete protection. |
| `modules/gcp/alloydb` | Google Cloud AlloyDB clusters with instances, automated/continuous backup config, and on-demand backups. |
| `modules/gcp/bigquery` | Google BigQuery datasets with IAM bindings and nested tables (partitioning, clustering, views, external data). |
| `modules/gcp/spanner` | Google Cloud Spanner instances with databases, CMEK encryption, autoscaling, and IAM bindings. |
| `modules/gcp/memorystore` | Google Cloud Memorystore Redis/Valkey instances. |
| `modules/gcp/redis-cluster` | Google Cloud Memorystore for Redis Cluster instances with PSC endpoints and maintenance windows. |
| `modules/gcp/bigtable` | Google Cloud Bigtable instances with clusters, tables, column families, GC policies, app profiles, and IAM bindings. |
| `modules/gcp/dns-zone` | Google Cloud DNS managed zones: public, private, forwarding, and peering zones. |
| `modules/gcp/dns-record-sets` | Google Cloud DNS resource record sets in a single managed zone, with weighted/geo/primary-backup routing policies. |
| `modules/gcp/eventarc` | Google Cloud Eventarc standalone triggers delivering to Cloud Run, GKE, Workflows, or HTTP endpoints. |
| `modules/gcp/cloud-run` | Google Cloud Run services with optional IAM bindings. |
| `modules/gcp/cloud-run-jobs` | Google Cloud Run jobs with optional IAM bindings. |
| `modules/gcp/cloud-build` | Google Cloud Build triggers with inline or repo-defined builds and manual approval gates. |
| `modules/gcp/cloud-functions` | Google Cloud Functions (2nd gen) with build/service/event-trigger config and optional IAM bindings. |
| `modules/gcp/dataproc` | Google Cloud Dataproc clusters with GCE cluster config and IAM bindings. |
| `modules/gcp/dataflow` | Google Cloud Dataflow jobs launched from classic templates. |
| `modules/gcp/datastream` | Google Cloud Datastream private connections, connection profiles (MySQL, PostgreSQL, Oracle, SQL Server, MongoDB, GCS, BigQuery), and CDC streams. |
| `modules/gcp/monitoring` | Google Cloud Monitoring dashboards and alert policies. |
| `modules/gcp/secret-manager` | Google Secret Manager secrets with optional versions, replication, rotation, and IAM bindings. |
| `modules/gcp/pubsub` | Google Pub/Sub topics with nested subscriptions (push/pull/BigQuery/Cloud Storage) and IAM bindings. |
| `modules/gcp/workload-identity-federation` | Google Workload Identity Federation pools, providers (OIDC/SAML/AWS/X.509), and service account token-creator grants. |
| `modules/gcp/cloud-tasks` | Google Cloud Tasks queues with rate/retry limits, HTTP target overrides, and optional IAM bindings. |
| `modules/gcp/cloud-scheduler` | Google Cloud Scheduler jobs with Pub/Sub, HTTP, and App Engine targets. |
| `modules/gcp/cloud-workflows` | Google Workflows with CMEK, call logging, execution history levels, and runtime env vars. |
| `modules/gcp/cloud-composer` | Google Cloud Composer (Managed Airflow Gen 3) environments with software, workload, maintenance, and recovery config. |
| `modules/gcp/notification-channels` | Google Cloud Monitoring notification channels (email, Slack, PagerDuty, webhook, ...) referenced by alert policies. |
| `modules/gcp/vertex-ai` | Google Cloud Vertex AI prediction endpoints (PSC/PSA networking, CMEK, request-response logging, traffic split) and Model Garden model deployments. |
| `modules/gcp/vertex-ai-dataset` | Google Cloud Vertex AI datasets with CMEK encryption and labels. |
| `modules/gcp/vertex-ai-index` | Google Cloud Vertex AI Vector Search indexes (batch/stream update, tree-AH or brute force, CMEK). |
| `modules/gcp/vertex-ai-index-endpoint` | Google Cloud Vertex AI Vector Search index endpoints (PSA/PSC/public) with deployed indexes. |
| `modules/stackit/folder` | STACKIT Resource Manager folders under an organization or parent folder. |
| `modules/stackit/project` | STACKIT Resource Manager projects under an organization or folder. |
| `modules/stackit/organization_role_assignment` | STACKIT authorization role assignments on an organization. |
| `modules/stackit/folder_role_assignment` | STACKIT authorization role assignments on a folder. |
| `modules/stackit/project_role_assignment` | STACKIT authorization role assignments on a project. |
| `modules/stackit/service_account_role_assignment` | STACKIT authorization 'Act-As' role assignments on a service account. |
| `modules/stackit/service_account` | STACKIT service accounts in a project (email and service account ID). |
| `modules/stackit/service_account_key` | STACKIT service account keys (key JSON, optional TTL and rotation trigger). |
| `modules/stackit/network` | STACKIT virtual networks with IPv4/IPv6 prefixes, gateways, nameservers, and DHCP. |
| `modules/stackit/network_area` | STACKIT network areas (SNA) at organization level; the parent of classic networks and their prefix pools. |
| `modules/stackit/network_area_region` | STACKIT network area regional configuration: transfer network, IPv4 ranges, prefix bounds, and default nameservers per region. |
| `modules/stackit/network_area_route` | STACKIT network area routes (SNA): destination CIDR with an IPv4, `blackhole`, or `internet` next hop, per region. |
| `modules/stackit/network_interface` | STACKIT network interfaces with explicit IPv4, security groups, and allowed address pairs. |
| `modules/stackit/security_group` | STACKIT security groups with optional inline security group rules. |
| `modules/stackit/security_group_rule` | STACKIT security group rules on existing security groups. |
| `modules/stackit/public_ip` | STACKIT public IP addresses, optionally associated with a network interface. |
| `modules/stackit/vpn_gateway` | STACKIT VPN gateways (IPsec, two tunnels, routing type and BGP options). |
| `modules/stackit/vpn_connection` | STACKIT VPN IPsec connections on a VPN gateway, with IKE phase settings and write-only pre-shared keys. |
| `modules/stackit/load_balancer` | STACKIT load balancers with listeners, target pools, and targets. |
| `modules/stackit/object_storage` | STACKIT Object Storage buckets, credentials groups, and credentials. |
| `modules/stackit/observability_instance` | STACKIT Observability instances with plan, ACL, retention, Grafana admin, and alerting configuration. |
| `modules/stackit/observability_credential` | STACKIT Observability write credentials with API-generated passwords and a rotation trigger. |
| `modules/stackit/ske` | STACKIT Kubernetes Engine clusters with node pools and optional kubeconfigs. |
| `modules/stackit/ske_kubeconfig` | STACKIT short-lived SKE kubeconfigs for existing clusters, with expiry and in-place refresh. |
| `modules/stackit/server` | STACKIT servers (virtual machines) booting from an image or boot volume. |
| `modules/stackit/affinity_group` | STACKIT affinity groups (placement policies) referenced by servers. |
| `modules/stackit/server_backup_enable` | STACKIT enabling of the server backup service (destroy disables it). |
| `modules/stackit/server_backup_schedule` | STACKIT server backup schedules (RFC 5545 rrule, requires backup enable). |
| `modules/stackit/server_update_enable` | STACKIT enabling of the server update service (destroy disables it). |
| `modules/stackit/server_update_schedule` | STACKIT server update schedules with maintenance window (requires update enable). |
| `modules/stackit/volume` | STACKIT block-storage volumes, optionally created from an image/snapshot source. |
| `modules/stackit/image` | STACKIT images uploaded from local image files. |
| `modules/stackit/key_pair` | STACKIT SSH key pairs for server authentication. |
| `modules/stackit/dns_zone` | STACKIT DNS zones (primary/secondary) with SOA tuning and reverse-zone support. |
| `modules/stackit/dns_record_set` | STACKIT DNS record sets (A, AAAA, CNAME, MX, TXT, ...) inside a DNS zone. |
| `modules/stackit/secrets_manager` | STACKIT Secrets Manager instances with ACLs and optional KMS encryption. |
| `modules/stackit/postgresflex_instance` | STACKIT PostgreSQL Flex instances with storage, flavor, network ACL, and backup schedule. |
| `modules/stackit/postgresflex_database` | STACKIT PostgreSQL Flex databases inside an existing instance. |
| `modules/stackit/postgresflex_user` | STACKIT PostgreSQL Flex database users with roles and API-generated passwords. |
| `modules/stackit/kms_keyring` | STACKIT KMS keyrings (not destroyed by `terraform destroy`, dropped from state only). |
| `modules/stackit/kms_key` | STACKIT KMS keys inside a keyring (destroy schedules deletion, keys are recoverable within the grace period). |
| `modules/stackit/mongodbflex_instance` | STACKIT MongoDB Flex instances with flavor, storage, ACL, and backup options. |
| `modules/stackit/mongodbflex_user` | STACKIT MongoDB Flex database users with roles and API-generated passwords. |
| `modules/stackit/mariadb_instance` | STACKIT MariaDB instances with plan and service parameters. |
| `modules/stackit/mariadb_credential` | STACKIT MariaDB credentials with API-generated passwords. |
| `modules/stackit/opensearch_instance` | STACKIT OpenSearch instances with plan and service parameters. |
| `modules/stackit/opensearch_credential` | STACKIT OpenSearch credentials with API-generated passwords. |
| `modules/stackit/logme_instance` | STACKIT LogMe instances with plan and service parameters. |
| `modules/stackit/logme_credential` | STACKIT LogMe credentials with API-generated passwords. |
| `modules/stackit/rabbitmq_instance` | STACKIT RabbitMQ instances with plan and service parameters. |
| `modules/stackit/rabbitmq_credential` | STACKIT RabbitMQ credentials with API-generated passwords. |
| `modules/stackit/redis_instance` | STACKIT Redis instances with plan and service parameters (deprecated upstream, use valkey). |
| `modules/stackit/sqlserverflex_instance` | STACKIT SQLServer Flex instances with flavor, storage, ACL, and backup options. |
| `modules/stackit/sqlserverflex_user` | STACKIT SQLServer Flex database users with roles and API-generated passwords. |
| `modules/stackit/sqlserverflex_database` | STACKIT SQLServer Flex databases inside an existing instance. |
| `modules/stackit/valkey_instance` | STACKIT Valkey instances with plan and service parameters. |
| `modules/stackit/valkey_credential` | STACKIT Valkey credentials with API-generated passwords. |
| `modules/stackit/secrets_manager_user` | STACKIT Secrets Manager users with auto-generated credentials. |
| `modules/stackit/public_ip_associate` | STACKIT associations of existing public IPs to network interfaces. |
| `modules/stackit/server_volume_attach` | STACKIT attachments of existing volumes to servers. |
| `modules/stackit/server_network_interface_attach` | STACKIT attachments of network interfaces to servers, effective after reboot. |
| `modules/stackit/server_service_account_attach` | STACKIT attachments of service accounts to servers. |
| `modules/snowflake/resource-monitor` | Snowflake resource monitors: credit quotas with notify and suspend triggers; warehouse or consumer-side account attachment. |
| `modules/snowflake/alert` | Snowflake alerts in a database/schema: condition and action SQL, interval or cron schedules. Provider preview feature. |
| `modules/snowflake/email-notification-integration` | Snowflake email notification integrations for SQL-driven sends (`SYSTEM$SEND_EMAIL`). Provider preview feature. |
| `modules/snowflake/warehouse` | Snowflake warehouses with sizes, multi-cluster config, query acceleration, and resource-monitor attachment. |
| `modules/snowflake/account-role` | Snowflake account roles; pair with the grant modules. |
| `modules/snowflake/role-grant` | Snowflake account-role grants to users and parent roles (role hierarchy edges). |
| `modules/snowflake/grant-privileges` | Snowflake privilege grants to account roles: account, account-object, schema-level and schema-object targets incl. all/future/inherited. |
| `modules/snowflake/user` | Snowflake users: identity, key-pair auth, session defaults, lifecycle. |

All modules are map-keyed. Pin with `?ref=vX.Y.Z` at the consumer side.

## Support

These modules are open source and free to use. For help architecting or
managing Terraform infrastructure at scale, [xtralinux.com](https://xtralinux.com)
offers consulting and managed IaC — [get in touch](https://xtralinux.com).

## License

These modules are released under the MIT License — see [LICENSE](LICENSE).
